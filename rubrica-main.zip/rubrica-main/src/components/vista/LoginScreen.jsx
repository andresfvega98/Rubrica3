import React from 'react'
import Login from '../Login/Login'

const LoginScreen = () => {
  return (
    <>
    <Login />
    </>
  )
}

export default LoginScreen